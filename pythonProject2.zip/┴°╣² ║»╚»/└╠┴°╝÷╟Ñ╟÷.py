t = 0.1
print(f'{t:.60f}')